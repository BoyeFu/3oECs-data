function B = zero_pad(A, k)
% 
% pad zeros around entire outside of array to width k
%
%%%  B = padarray( padarray(A, k)', k)';
  
[mA,nA] = size(A);
B = [[zeros(k,k)  zeros(k,nA) zeros(k,k)];
     [zeros(mA,k) A           zeros(mA,k)];
     [zeros(k,k)  zeros(k,nA) zeros(k,k)];
    ];