%
% file:      	surf2solid_polar_ex.m, (c) Matthew Roughan, Wed Mar  9 2011
% directory:   /home/mroughan/src/matlab/STL/
% created: 	Wed Mar  9 2011 
% author:  	Matthew Roughan 
% email:   	matthew.roughan@adelaide.edu.au
% 
% convert a surface in polar form, to a solid, suitable for export as STL
%
%

% plot a Gaussian distribution
% n = 24;
% dp = 2*pi/(n-1);
% theta = 0:dp:2*pi;
% 
% m = 30;
% r = repmat([0:m-1]', 1, n);
% z = 10*exp( -r.^2 / 100 );
% 
% % convert to a solid
% [theta_out, r_out, Z_out, X_out, Y_out] = surf2solid_polar(theta, r, z);
% %print('-dpng', 'Plots/surf2solid_polar_ex.fig');
% 
% % output a STL version of the solid
% filename = 'surf2solid_polar_ex.stl';
% mode = 'binary';
% surf2stl(filename,X_out,Y_out,Z_out,mode);



% % do Gary's surface on cylinder
clear;
n = 73;
dp = 2*pi/(n-1);
theta = 0:dp:2*pi;

m = 30;
r = repmat([0:m-1]', 1, n);
z = r .* sin(3*repmat(theta,m,1))/3;

% convert to a solid
[theta_out, r_out, Z_out, X_out, Y_out] = surf2solid_polar(theta, r, z, 20, 1);
print('-dpng', 'garys_surface_polar.png');


% output a STL version of the solid
filename = 'garys_surface_polar.stl';
mode = 'binary';
surf2stl(filename,X_out,Y_out,Z_out,mode);
figure(2)
mesh(X_out, Y_out, Z_out);


% do an example on an irregular region
% clear;
% n = 37;
% dp = 2*pi/(n-1);
% theta = 0:dp:2*pi;
% 
% m = 30;
% r = [0:m]' * (cos(3*theta)+2);
% 
% z = ones(size(r));
% 
% % convert to a solid
% [theta_out, r_out, Z_out, X_out, Y_out] = surf2solid_polar(theta, r, z, 20, 5);
% print('-dpng', 'surf2solid_polar_ex_2.png');
% 
% 
% % output a STL version of the solid
% filename = 'surf2solid_polar_ex_2.stl';
% mode = 'binary';
% surf2stl(filename,X_out,Y_out,Z_out,mode);


