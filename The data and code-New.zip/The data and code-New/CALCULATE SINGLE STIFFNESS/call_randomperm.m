function [perm, str] = call_randomperm(dist, Nx, Ny, Lx, Ly, CLx, CLy, var_lnk)

%%% Network Dimension
hx = Lx/Nx;                 hy = Ly/Ny;%The interval in the direction of x and y
x = -Lx/2:hx:(Lx/2)-hx;     y = -Ly/2:hy:(Ly/2)-hy;%The variation of x and y

[xx,yy] = meshgrid(x,y);%The network for simultaion
disp(['Grid: ',num2str(Nx),'x',num2str(Ny),'.'])
disp(['Dimension: ',num2str(Lx),'x',num2str(Ly),'.'])

%%% Wave Numbers
kx = (2*pi/Lx)*[0:(Nx/2-1) (-Nx/2):(-1)]';%What the meaning of this?
ky = (2*pi/Ly)*[0:(Ny/2-1) (-Ny/2):(-1)]';%why don't you just use that ky = [-(Ny/2):(Ny/2-1)]
[KX,KY] = meshgrid(kx,ky);%The network of wave number
KX2 = KX.^2;
KY2 = KY.^2;

%%% Heterogeneity of Network
disp(['Variance of ln(Conductivity) = ',num2str(var_lnk),'.'])

corr_lenx = CLx;            % x-directional correlation length
corr_leny = CLy;            % y-directional correlation length
disp(['Correlation Lengths: ',num2str(corr_lenx),',',num2str(corr_leny),'.'])

% Generate perm field until the logk variance is within desired tolerance
tol = 0.005*var_lnk;        % tolerance to accept around var_lnk
var_lnk_old = 0;            % initialization
perm_old = 1;               % initialization
i = 0;                      % iteration counter
max_iter = 200;             % max iterations

if var_lnk == 0
    perm = ones(Ny,Nx);     % constant permeability
else
    while (abs(var_lnk_old-var_lnk)>tol && i<max_iter)
        [perm, var_lnk_actual, str] = randomperm(dist, var_lnk, CLx, CLy, KX2, KY2);%What is this function
        % keep if new perm field has var closer to wanted, else discard 
        if abs(var_lnk_actual-var_lnk) < abs(var_lnk_old-var_lnk)
            var_lnk_old = var_lnk_actual;%Which means the the real variance is near from the actual variance
            perm_old = perm;
        end
        i = i+1;
    end
    perm = perm_old; 
    var_lnk_actual = var_lnk_old; 
    clear perm_old var_lnk_old;
end

disp(['Arithmatic and Geometric Permeability Mean = ',num2str(mean(perm(:))),',',num2str(geomean(perm(:))),'.'])
disp(['Variance of Permeability = ',num2str(var(perm(:))),'.'])

fname_perm = sprintf('Perm_N%d_L%d_CL%.2f_var%.2f_dist%d.mat', Nx, Lx, CLx, var_lnk, dist);
save(fname_perm, 'perm','var_lnk', 'Nx', 'Ny', 'Lx', 'Ly', 'CLx', 'CLy', 'KX2', 'KY2');

end