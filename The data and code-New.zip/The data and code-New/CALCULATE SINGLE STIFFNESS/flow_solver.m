%%% Run for same fracture system with heterogeneous and homogeneous permeability field
% pmat: pressure value at the center of each grid
% fx: x-directional flux at the interfaces of each grid
% fy: y-directional flux at the interfaces of each grid
% vx: x-directional velocity at the interfaces of each grid
% vy: y-directional velocity at the interfaces of each grid

function [pmat, fx, fy, fx_centre, fy_centre] = flow_solver(Lx, Nx, Ny, Kx, Ky,PP)
%Now what we have is permeability
% Grid 
%h = 50;
h = Lx/(Nx-1); %[m]%The interval in x direction

%Assemble transmissivity matrix
[Amm, bvec, Txmat, Tymat] = assemb_mm2_v2(Nx, Ny, Kx, Ky, h);%transmissivity matrix
%we have the coefficient matrix boundary condition transmissivity
% Solve system
pvec = Amm\bvec;%This is the pressure
pmat = reshape(pvec,Ny,Nx).*PP;
% pmat = reshape(pvec,Ny,Nx);
% Fluxes (matrix)
% fx = Txmat.*([pmat,pmat(:,Ny),]-[pmat(2:Nx,:),zeros(Ny,1)])*Lx;%The right hand is the gradient of the pressure
fx = Txmat.*([ones(Ny,1),pmat]-[pmat,zeros(Ny,1)]).*Lx/h;%The right hand is the gradient of the pressure
% fy = Tymat.*([pmat;zeros(1,Nx)]-[zeros(1,Nx);pmat])*Lx;%The right hand is the gradient of the pressure
% fy = Tymat.*([pmat;pmat(Nx,:)]-[pmat;zeros(1,Nx)])*Lx;%The right hand is the gradient of the pressure
fy = Tymat.*([ones(1,Nx);pmat]-[pmat;zeros(1,Nx)]).*Lx/h;
%Txmat = zeros(Ny,Nx+1); 
%Tymat = zeros(Ny+1,Nx);
% find centered flux, added bu joseph on 11 April 2017 
% fx_centre = movmean(fx,2,2,'Endpoints','discard');  % average over 2 points along rows
% fy_centre = movmean(fy,2,1,'Endpoints','discard');  % average over 2 points along columns
fx_centre = movmean(fx(:,2:end),2,2);  % average over 2 points along rows
fy_centre = movmean(fy(2:end,:),2,2);  % average over 2 points along columns

%{
% Velocities
% Calculate transmissibilities at interfaces (general case - homo, hetero)
bymat(2:Ny,:) = (eff_poro(1:Ny-1,:)+eff_poro(2:Ny,:))/2; % No boundary condition: 0 for 1 and Nx+1 -> therefore 2:Nx
bxmat(:,2:Nx) = (eff_poro(:,1:Nx-1)+eff_poro(:,2:Nx))/2;

% Impose no flow B.C at x edges.
bxmat(:,1) = (eff_poro(:,1)+eff_poro(:,1))/2; 
bxmat(:,Nx+1) = (eff_poro(:,Nx)+eff_poro(:,Nx))/2;
bymat(1,:) = inf; 
bymat(Ny+1,:) = inf;

vx = fx./bxmat;
vy = fy./bymat;

% vx= bxmat.*([zeros(Ny,1),pmat]-[pmat,zeros(Ny,1)]);
% vy= bymat.*([zeros(1,Nx);pmat]-[pmat;zeros(1,Nx)]);
%}

end
