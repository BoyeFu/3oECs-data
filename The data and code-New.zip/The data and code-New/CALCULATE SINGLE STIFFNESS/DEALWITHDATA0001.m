%%The figure for the video
EH = 1e-05;
LN = [2	5 10 100 1000 10000];
LL =LN.*EH./1e-06;
PERTP0 = [1.18E+04 2.96E+04 4.78E+04 5.77E+04 8.61E+04 9.77E+04];
PERTP01 = [3.20E+03	7.54E+03 1.21E+04 3.77E+04 6.04E+04 7.06E+04];
PERTWP01 = [4.04E+03 7.61E+03 1.24E+04 3.78E+04 6.06E+04 7.09E+04];
PERWTP01 = [1.40E+04 4.82E+04 8.18E+04 1.15E+05 1.15E+05 1.15E+05];
%%
%The figure for pressure
PRE = [0	0.084869896	0.228862388	0.417799216	0.679756381	0.948114227	1.267218185];
PERMPT = [57747.39806	37677.40728	28169.09678	22655.5135	18756.36519	16275.10771	14214.41475];
PERMWPT = [57747.39413	37821.38332	28494.37484	23197.24579	19551.99235	17310.14489	15504.34563];
PERMPWT = [114902.3277	73817.28266	54083.08075	42773.94089	34857.80101	29874.52422	25737.12213];
%%
AUOT = [2.00E-04	1.00E-04	5.00E-05	1.00E-05	6.67E-06	5.00E-06]./1e-06;
PERTP001 = [1.81E+03	8.09E+03	2.14E+04	3.90E+04	4.09E+04	3.78E+04];
PERTP002 = [228.1575	5.66E+03	1.14E+04	2.50E+04	2.59E+04	2.48E+04];
PERTWP = [290.5236	5.76E+03	1.16E+04	2.52E+04	2.62E+04	2.51E+04];
PERWTP = [1.97E+03	1.32E+04	4.01E+04	7.64E+04	8.04E+04	7.42E+04];
%%
%Plot the figure
figure(1)
plot(PRE,PERMPT)
hold on
plot(PRE,PERMWPT)
hold on
plot(PRE,PERMPWT)
xlabel('Pressure (MPa)')
ylabel('Permeability (mD)')
legend('The result considering turbulance and Poisson effect','The result considering turbulance','The result considering Poisson effect')
%%
figure(2)
plot(LL,PERTP0)
hold on
plot(LL,PERWTP01)
xlabel('Length (um)')
ylabel('Permeability (mD)')
legend('The result with turbulance','The result without turbulance')
%%
figure(3)
plot(LL,abs(PERTP0-PERWTP01)./PERTP0*100)
xlabel('Length (um)')
ylabel('Error (%)')
%%
figure(4)
plot(AUOT,PERTP001)
hold on
plot(AUOT,PERWTP)
xlabel('Autocorrelation length (um)')
ylabel('Permeability (mD)')
legend('The result with turbulance','The result without turbulance')
%%
figure(5)
plot(AUOT,abs(PERTP001-PERWTP)./PERTP001.*100)
xlabel('Autocorrelation length (um)')
ylabel('Error (%)')
%%
%Poisson effect
figure(6)
plot(LL,PERTP01)
hold on
plot(LL,PERTWP01)
xlabel('Length (um)')
ylabel('Permeability (mD)')
legend('The result with Poisson effect','The result without Poisson effect')
%%
figure(7)
plot(LL,abs(PERTP01-PERTWP01)./PERTP01*100)
xlabel('Length (um)')
ylabel('Error (%)')
%%
figure(8)
plot(AUOT,PERTP002)
hold on
plot(AUOT,PERTWP)
xlabel('Autocorrelation length (um)')
ylabel('Permeability (mD)')
legend('The result with Poisson effect','The result without Poisson effect')
%%
figure(9)
plot(AUOT,abs(PERTP002-PERTWP)./PERTP002.*100)
xlabel('Autocorrelation length (um)')
ylabel('Error (%)')