%%
% The code is used to model the surface
clear
%%
Nx = 128; Ny = 128;          % grid numbers ,
NNNN = 100;
SCALE = 1e-04;
Lx = NNNN.*SCALE; Ly = NNNN.*SCALE;          % domain lengths m
DX = Lx./Nx.*(1:Nx)./1e-02;
DY = Ly./Ny.*(1:Ny)./1e-02;
[DDX, DDY] = meshgrid(DX,DY);
%%
SURF009P00 = load('S2N-0.0009.txt');
SURF009P00(1,:) = max(max(SURF009P00));
SURF009P00(end,:) = max(max(SURF009P00));
SURF009P00(:,1) = max(max(SURF009P00));
SURF009P00(:,end) = max(max(SURF009P00));
SURF009P00UP = max(max(SURF009P00)).*ones(Ny,Nx);
SURF009P45 = load('S2N-0.0009-08-02.txt');
SURF009P45UP = max(max(SURF009P45)).*ones(Ny,Nx);
SURF018P00 = load('S2N-0.0018.txt');
SURF018P00(1,:) = max(max(SURF018P00));
SURF018P00(end,:) = max(max(SURF018P00));
SURF018P00(:,1) = max(max(SURF018P00));
SURF018P00(:,end) = max(max(SURF018P00));
SURF018P00UP = max(max(SURF018P00)).*ones(Ny,Nx);
SURF018P45 = load('S2N-0.0018-08-02.txt');
SURF018P45UP = max(max(SURF018P45)).*ones(Ny,Nx);
APTF009P00 = max(max(SURF009P00))-SURF009P00;
APTF009P45 = max(max(SURF009P45))-SURF009P45;
APTF018P00 = max(max(SURF018P00))-SURF018P00;
APTF018P45 = max(max(SURF018P45))-SURF018P45;
S009P00 = 0;
S018P00 = 0;
S009P45 = 0;
S018P45 = 0;
%%
for I = 1:Ny
    for J = 1:Nx
        if abs(APTF009P00(I,J)) == 0
            S009P00 = S009P00+1;
        end
    end
end
for I = 1:Ny
    for J = 1:Nx
        if abs(APTF018P00(I,J)) == 0
            S018P00 = S018P00+1;
        end
    end
end
%%
for I = 1:Ny
    for J = 1:Nx
        if abs(APTF009P45(I,J)) == 0
            S009P45 = S009P45+1;
        end
    end
end
for I = 1:Ny
    for J = 1:Nx
        if abs(APTF018P45(I,J)) == 0
            S018P45 = S018P45+1;
        end
    end
end
%%
figure(1)
surf(DDX,DDY,SURF009P00./1e-02)
% hold on
% surf(DDX,DDY,SURF009P00UP./1e-06)
xlabel('Length (cm)')
ylabel('Length (cm)')
zlabel('Height (cm)')
figure(2)
imagesc(DX,DY,APTF009P00./1e-02);
xlabel('Length (cm)')
ylabel('Length (cm)')
axis square
figure(3)
surf(DDX,DDY,SURF018P00./1e-02)
% hold on
% surf(DDX,DDY,SURF018P00UP./1e-06)
xlabel('Length (cm)')
ylabel('Length (cm)')
zlabel('Height (cm)')
figure(4)
imagesc(DX,DY,APTF018P00./1e-02);
xlabel('Length (cm)')
ylabel('Length (cm)')
axis square
%%
figure(5)
surf(DDX,DDY,SURF009P45./1e-02)
% hold on
% surf(DDX,DDY,SURF009P89UP./1e-06)
xlabel('Length (cm)')
ylabel('Length (cm)')
zlabel('Height (cm)')
figure(6)
imagesc(DX,DY,APTF009P45./1e-02);
xlabel('Length (cm)')
ylabel('Length (cm)')
axis square
figure(7)
surf(DDX,DDY,SURF018P45./1e-02)
% hold on
% surf(DDX,DDY,SURF018P89UP./1e-06)
xlabel('Length (cm)')
ylabel('Length (cm)')
zlabel('Height (cm)')
figure(8)
imagesc(DX,DY,APTF018P45./1e-02);
xlabel('Length (cm)')
ylabel('Length (cm)')
axis square